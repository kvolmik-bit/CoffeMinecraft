Square transparent coffee mug - item model for Minecraft 1.20.1 (Forge)
=======================================================================

1) Rename the "yourmodid" folder to your real mod id and replace "yourmodid"
   inside models/item/coffee_mug.json (texture lines) and in lang/*.json.

2) Copy assets/ to  src/main/resources/assets/

   textures/item/coffee_mug_glass.png    16x16  glass walls and base
   textures/item/coffee_mug_coffee.png   16x16  coffee body
   textures/item/coffee_mug_crema.png    16x16  coffee surface (top face)
   textures/item/coffee_mug_handle.png   16x16  handle

3) Register the item "coffee_mug" (the code from the previous version still works):

   public static final DeferredRegister<Item> ITEMS =
       DeferredRegister.create(ForgeRegistries.ITEMS, YourMod.MODID);

   public static final RegistryObject<Item> COFFEE_MUG = ITEMS.register("coffee_mug",
       () -> new Item(new Item.Properties().stacksTo(1)));

   ITEMS.register(modEventBus);   // in the mod constructor

Notes
- Model: 9 elements, no rotated parts. Coffee is listed first so the translucent
  glass draws over it.
- Glass alpha is about 58 on the walls and up to 150 on the highlights; the top
  row of the glass texture gives the rim.
- Display transforms are in the JSON (gui, ground, fixed, head, thirdperson and
  firstperson for both hands). Open the model in Blockbench -> Display tab to tune.
